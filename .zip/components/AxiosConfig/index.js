export { default } from "./AxiosConfig";
